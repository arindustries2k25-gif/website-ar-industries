
# AR Industries Website

This is the official website for **AR Industries** built with **Next.js 14 + TailwindCSS**.

## Features
- Social Media Marketing Packages
- Content Creation Packages
- AI Chatbot Setup
- Luxury Gold/Black Theme
- Functional Contact Form (via Formspree)

## Deployment (Vercel)
1. Push this repo to GitHub
2. Import into [Vercel](https://vercel.com)
3. Add Environment Variable:
   - `NEXT_PUBLIC_FORMSPREE_ENDPOINT = https://formspree.io/f/{your_id}`
4. Deploy 🚀
