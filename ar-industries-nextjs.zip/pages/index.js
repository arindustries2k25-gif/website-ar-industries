
import Image from 'next/image'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white text-brandBlack">
      <header className="bg-brandBlack text-brandGold p-6 text-center">
        <div className="flex justify-center mb-4">
          <Image src="/logo.jpg" alt="AR Industries" width={100} height={100} />
        </div>
        <h1 className="text-3xl font-bold">AR Industries</h1>
        <p className="mt-2">Social Media Marketing • Content Creation • AI Chatbots</p>
      </header>

      <section className="p-8 max-w-5xl mx-auto">
        <h2 className="text-2xl font-semibold text-brandGold mb-4">Our Services</h2>
        <ul className="space-y-2">
          <li>📱 Social Media Management</li>
          <li>🎨 Premium Content Creation</li>
          <li>🤖 AI Chatbot Setup & Maintenance</li>
        </ul>
      </section>

      <section className="p-8 max-w-5xl mx-auto">
        <h2 className="text-2xl font-semibold text-brandGold mb-4">Packages & Pricing (MYR)</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="border p-4 rounded-xl shadow">
            <h3 className="text-xl font-bold">SMM Starter</h3>
            <p className="text-sm">MYR 1,200 / month</p>
            <ul className="mt-2 text-sm">
              <li>12 Posts</li>
              <li>8 Stories</li>
              <li>Monthly Report</li>
            </ul>
          </div>
          <div className="border p-4 rounded-xl shadow">
            <h3 className="text-xl font-bold">Content Pro</h3>
            <p className="text-sm">MYR 2,500 / month</p>
            <ul className="mt-2 text-sm">
              <li>12 Reels</li>
              <li>20 Stories</li>
              <li>Premium Edits</li>
            </ul>
          </div>
          <div className="border p-4 rounded-xl shadow">
            <h3 className="text-xl font-bold">AI Chatbot</h3>
            <p className="text-sm">MYR 3,000 setup + 500 / month</p>
            <ul className="mt-2 text-sm">
              <li>Custom Chatbot Flow</li>
              <li>WhatsApp & Instagram</li>
              <li>Ongoing Support</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="p-8 max-w-2xl mx-auto">
        <h2 className="text-2xl font-semibold text-brandGold mb-4">Contact Us</h2>
        <form method="POST" action={process.env.NEXT_PUBLIC_FORMSPREE_ENDPOINT} className="space-y-4">
          <input type="text" name="name" placeholder="Your Name" className="w-full p-2 border rounded" required />
          <input type="email" name="email" placeholder="Your Email" className="w-full p-2 border rounded" required />
          <textarea name="message" placeholder="Your Message" className="w-full p-2 border rounded" rows="4" required></textarea>
          <button type="submit" className="bg-brandGold text-white px-4 py-2 rounded">Send</button>
        </form>
      </section>

      <footer className="bg-brandBlack text-brandGold text-center p-4 mt-auto">
        © {new Date().getFullYear()} AR Industries. All Rights Reserved.
      </footer>
    </div>
  )
}
